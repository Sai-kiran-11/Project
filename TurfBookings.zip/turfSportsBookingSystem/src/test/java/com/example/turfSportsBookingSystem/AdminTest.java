package com.example.turfSportsBookingSystem;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.turfSportsBookingSystem.service.AdminService;

@SpringBootTest
class AdminTest {

	@Autowired
	AdminService adminService;
	
	@Test
	public void testsAllAdmin(){
		assertNotNull(adminService.findAll());
	}
	@Test
	public void testAdminById() {
		assertNotNull(adminService.findById(1));
	}
	@Test
	public void testAdminByName() {
		assertNotNull(adminService.findByName("sai kiran"));
	}
	@Test
	public void testAdminByEmail() {
		assertNotNull(adminService.getByEmail("sai@gmail.com"));
	}
}
