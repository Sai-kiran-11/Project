package com.example.turfSportsBookingSystem;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.turfSportsBookingSystem.service.TimeSlotService;

@SpringBootTest
class TimeSlotsTest {
	
	@Autowired
	TimeSlotService timeslotService;
	@Test
	public void testAllTimeSlots() {
		assertNotNull(timeslotService.findAll());
	}
	@Test
	public void testTimeSlotBySportId() {
		assertNotNull(timeslotService.getBySportsId(1));
	}
	@Test
	public void testTimeSlotById() {
		assertNotNull(timeslotService.getById(2));
	}
	@Test
	public void testTimeSlotByDuration() {
		assertNotNull(timeslotService.getByDuration("One-Hour"));
	}

}
