package com.example.turfSportsBookingSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TurfSportsBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
