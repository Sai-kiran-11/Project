package com.example.turfSportsBookingSystem;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.turfSportsBookingSystem.service.SportsService;

@SpringBootTest
class SportsTest {
	
	@Autowired
	SportsService sportsService;
	
	@Test
	public void testAllSports() {
		assertNotNull(sportsService.findAll());
	}
	@Test
	public void testSportsById() {
		assertNotNull(sportsService.getById(2));
	}
	@Test
	public void testSportsByTurfId() {
		assertNotNull(sportsService.getByTurfId(1));
	}
	@Test
	public void testSportsByName() {
		assertNotNull(sportsService.getBySportsName("Cricket"));
	}
	@Test
	public void testSportsByPricePerHour() {
		assertNotNull(sportsService.getBySportsPricePerHour("1700"));
	}
}
