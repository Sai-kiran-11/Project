package com.example.turfSportsBookingSystem;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.turfSportsBookingSystem.service.TurfService;

@SpringBootTest
class TurfTest {

	@Autowired
	TurfService turfService;
	
	
	@Test
	public void testTurfById() {
		assertNotNull(turfService.getById(1));
	}
	
	@Test
	public void testTurfByName() {
		assertNotNull(turfService.findAll());
	}
	@Test
	public void testTurfByLocation() {
		assertNotNull(turfService.getByTurfLocation("Hyderabad"));
	}
	
	
}

	