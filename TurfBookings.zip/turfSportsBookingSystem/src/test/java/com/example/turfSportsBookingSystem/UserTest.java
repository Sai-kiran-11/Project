package com.example.turfSportsBookingSystem;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.turfSportsBookingSystem.service.UserService;

@SpringBootTest
class UserTest {
	
	@Autowired
	UserService userService;
	
	@Test
	public void testAllUsers() {
		assertNotNull(userService.findAll());
	}
	@Test
	public void testUserById() {
		assertNotNull(userService.getById(2));
	}
	@Test
	public void testUserByName() {
		assertNotNull(userService.findByUserName("virat"));
	}
	@Test
	public void testUserByEmail() {
		assertNotNull(userService.findByEmail("kindofcricket@gmail.com"));
	}
	@Test
	public void testUserByAge() {
		assertNotNull(userService.findByAge(36));
	}

}
