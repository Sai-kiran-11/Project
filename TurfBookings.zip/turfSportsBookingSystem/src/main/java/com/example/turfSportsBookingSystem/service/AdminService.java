package com.example.turfSportsBookingSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.turfSportsBookingSystem.entity.Admin;
import com.example.turfSportsBookingSystem.exception.IdNotFoundException;
import com.example.turfSportsBookingSystem.exception.NameNotFoundException;
import com.example.turfSportsBookingSystem.exception.PasswordNotFoundException;
import com.example.turfSportsBookingSystem.repository.AdminRepository;



@Service
public class AdminService {
	@Autowired
	AdminRepository adminRepository;
	
	public List<Admin> findAll(){
		return adminRepository.findAll();
	}
	public Optional<Admin> findById(int id){
		if(adminRepository.findById(id).isEmpty()) {
			throw new IdNotFoundException("Requested ID is not present");
		}
		return adminRepository.findById(id);
	}
	public List<Admin> findByName(String name){
		if(adminRepository.findByName(name).isEmpty()) {
			throw new NameNotFoundException("Requested Name is not present");
		}
		return adminRepository.findByName(name);
	}
	public List<Admin> findByPassword(String password){
		if(adminRepository.findByPassword(password).isEmpty()) {
			throw new PasswordNotFoundException("Requested Password is not present");
		}
		return adminRepository.findByPassword(password);
	}
	public Admin addAdmin(Admin admin){
		return adminRepository.save(admin);
	}
	public String updateAdminName(int id,String password,String newName) {
		Optional<Admin> adminId = adminRepository.findById(id);
		if(adminId.isPresent()) {
			Admin admin = adminId.get();
			if(admin.getPassword().equals(password)) {
				admin.setName(newName);
				adminRepository.save(admin);
				return ("Name is successfully updated with : " + newName);
			}else {
				return "Password is not correct";
			}
		}else {
			return "Admin is not found with this id";
		}
		
	}
	public String updateAdminPassword(int id,String Oldpassword,String Newpassword) {
		Optional<Admin> adminId = adminRepository.findById(id);
		if(adminId.isPresent()) {
			Admin admin = adminId.get();
			if(admin.getPassword().equals(Oldpassword)) {
				admin.setPassword(Newpassword);
				adminRepository.save(admin);
				return "Password Updated Successfully";
			}else {
				return "Password Not matched with old password";
			}
		}else {
			return "Admin is not found with this id";
		}
	}

	public void deleteAdminById(int id) {
		 adminRepository.deleteById(id);
	}
	public Admin getByEmail(String email) {
		
		return adminRepository.findByEmail(email);
	}
}
