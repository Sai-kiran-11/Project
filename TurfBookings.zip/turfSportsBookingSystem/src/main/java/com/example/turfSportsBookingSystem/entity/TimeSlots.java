package com.example.turfSportsBookingSystem.entity;

import java.time.LocalTime;

import org.springframework.stereotype.Component;



//import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class TimeSlots {
	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	private int slotsId;
	
	private LocalTime startTime;
	private LocalTime endTime;
	
	private boolean availiability;
	
	private String duration;
	
	@ManyToOne
	private Sports sports;

////	@ManyToOne(cascade = CascadeType.MERGE)
////	@Override
////	public String toString() {
////		return "TimeSlots [slotsId=" + slotsId + ", startTime=" + startTime + ", endTime=" + endTime + ", availiability="
////				+ availiability + ", duration=" + duration + ", sports=" + sports + "]";
////	}
////
////
////	public TimeSlots(int slotsId, LocalTime startTime, LocalTime endTime, boolean availiability, String duration) {
////		super();
////		this.slotsId = slotsId;
////		this.startTime = startTime;
////		this.endTime = endTime;
////		this.availiability = availiability;
////		this.duration = duration;
////	}
////
////
////	public int getSlotsId() {
////		return slotsId;
////	}
////
////	public void setSlotsId(int slotsId) {
////		this.slotsId = slotsId;
////	}
////
////
////	public LocalTime getStartTime() {
////		return startTime;
////	}
////
////
////	public void setStartTime(LocalTime startTime) {
////		this.startTime = startTime;
////	}
////
////
////	public LocalTime getEndTime() {
////		return endTime;
////	}
////
////
////	public void setEndTime(LocalTime endTime) {
////		this.endTime = endTime;
////	}
////
////
////	public boolean isAvailable() {
////		return availiability;
////	}
////
////
////	public void setAvailable(boolean availiability) {
////		this.availiability = availiability;
////	}
////
////
////	public String getDuration() {
////		return duration;
////	}
////
////
////	public void setDuration(String duration) {
////		this.duration = duration;
////	}
////
////
////	public Sports getSports() {
////		return sports;
////	}
////
////
////	public void setSports(Sports sports) {
////		this.sports = sports;
////	}


	public TimeSlots() {
		
	}

	public int getSlotsId() {
		return slotsId;
	}

	public void setSlotsId(int slotsId) {
		this.slotsId = slotsId;
	}

	public LocalTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}

	public LocalTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalTime endTime) {
		this.endTime = endTime;
	}

	public boolean isAvailiability() {
		return availiability;
	}

	public void setAvailiability(boolean availiability) {
		this.availiability = availiability;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public Sports getSports() {
		return sports;
	}

	public void setSports(Sports sports) {
		this.sports = sports;
	}

	@Override
	public String toString() {
		return "TimeSlots [slotsId=" + slotsId + ", startTime=" + startTime + ", endTime=" + endTime
				+ ", availiability=" + availiability + ", duration=" + duration + ", sports=" + sports + "]";
	}

	public TimeSlots(int slotsId, LocalTime startTime, LocalTime endTime, boolean availiability, String duration,
			Sports sports) {
		super();
		this.slotsId = slotsId;
		this.startTime = startTime;
		this.endTime = endTime;
		this.availiability = availiability;
		this.duration = duration;
		this.sports = sports;
	}
	

}




































































//package com.example.turfSportsBookingSystem.entity;
//
//import java.time.LocalTime;
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//
//import org.springframework.stereotype.Component;
//
//import com.fasterxml.jackson.annotation.JsonBackReference;
//import com.fasterxml.jackson.annotation.JsonIgnore;
//
//import jakarta.persistence.CascadeType;
////import jakarta.persistence.CascadeType;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.ManyToMany;
//import jakarta.persistence.ManyToOne;
//import jakarta.persistence.OneToMany;
//
//@Entity
//public class TimeSlots {
//	@Id
////	@GeneratedValue(strategy =  GenerationType.IDENTITY)
//	private int slotsId;
//	
//	private LocalTime startTime;
//	private LocalTime endTime;
//	
//	private boolean availiability;
//	
//	private String duration;
//
//	@ManyToMany(mappedBy = "timeslots")
//	@JsonBackReference
//	private Set<Sports> sports = new HashSet<>();
//
//	public TimeSlots() {
//		super();
//	}
//
//	public int getSlotsId() {
//		return slotsId;
//	}
//
//	public void setSlotsId(int slotsId) {
//		this.slotsId = slotsId;
//	}
//
//	public LocalTime getStartTime() {
//		return startTime;
//	}
//
//	public void setStartTime(LocalTime startTime) {
//		this.startTime = startTime;
//	}
//
//	public LocalTime getEndTime() {
//		return endTime;
//	}
//
//	public void setEndTime(LocalTime endTime) {
//		this.endTime = endTime;
//	}
//
//	public boolean isAvailiability() {
//		return availiability;
//	}
//
//	public void setAvailiability(boolean availiability) {
//		this.availiability = availiability;
//	}
//
//	public String getDuration() {
//		return duration;
//	}
//
//	public void setDuration(String duration) {
//		this.duration = duration;
//	}
//
//	public Set<Sports> getSports() {
//		return sports;
//	}
//
//	public void setSports(Set<Sports> sports) {
//		this.sports = sports;
//	}
//
//	public TimeSlots(int slotsId, LocalTime startTime, LocalTime endTime, boolean availiability, String duration) {
//		super();
//		this.slotsId = slotsId;
//		this.startTime = startTime;
//		this.endTime = endTime;
//		this.availiability = availiability;
//		this.duration = duration;
//	}
//
//	@Override
//	public String toString() {
//		return "TimeSlots [slotsId=" + slotsId + ", startTime=" + startTime + ", endTime=" + endTime
//				+ ", availiability=" + availiability + ", duration=" + duration + ", sports=" + sports + "]";
//	}
//
//	
//
//	
//
//}





















//package com.example.turfSportsBookingSystem.entity;
//
//import java.time.LocalTime;
//
//import org.springframework.stereotype.Component;
//
//
//
////import jakarta.persistence.CascadeType;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.ManyToOne;
//
//@Entity
//public class TimeSlots {
//	@Id
//	@GeneratedValue(strategy =  GenerationType.IDENTITY)
//	private int slotsId;
//	
//	private LocalTime startTime;
//	private LocalTime endTime;
//	
//	private boolean availiability;
//	
//	private String duration;
//	
//	@ManyToOne
//	private Sports sports;
//
////	@ManyToOne(cascade = CascadeType.MERGE)
////	@Override
////	public String toString() {
////		return "TimeSlots [slotsId=" + slotsId + ", startTime=" + startTime + ", endTime=" + endTime + ", availiability="
////				+ availiability + ", duration=" + duration + ", sports=" + sports + "]";
////	}
////
////
////	public TimeSlots(int slotsId, LocalTime startTime, LocalTime endTime, boolean availiability, String duration) {
////		super();
////		this.slotsId = slotsId;
////		this.startTime = startTime;
////		this.endTime = endTime;
////		this.availiability = availiability;
////		this.duration = duration;
////	}
////
////
////	public int getSlotsId() {
////		return slotsId;
////	}
////
////	public void setSlotsId(int slotsId) {
////		this.slotsId = slotsId;
////	}
////
////
////	public LocalTime getStartTime() {
////		return startTime;
////	}
////
////
////	public void setStartTime(LocalTime startTime) {
////		this.startTime = startTime;
////	}
////
////
////	public LocalTime getEndTime() {
////		return endTime;
////	}
////
////
////	public void setEndTime(LocalTime endTime) {
////		this.endTime = endTime;
////	}
////
////
////	public boolean isAvailable() {
////		return availiability;
////	}
////
////
////	public void setAvailable(boolean availiability) {
////		this.availiability = availiability;
////	}
////
////
////	public String getDuration() {
////		return duration;
////	}
////
////
////	public void setDuration(String duration) {
////		this.duration = duration;
////	}
////
////
////	public Sports getSports() {
////		return sports;
////	}
////
////
////	public void setSports(Sports sports) {
////		this.sports = sports;
////	}
//
//
//	public TimeSlots() {
//		
//	}
//
//	public int getSlotsId() {
//		return slotsId;
//	}
//
//	public void setSlotsId(int slotsId) {
//		this.slotsId = slotsId;
//	}
//
//	public LocalTime getStartTime() {
//		return startTime;
//	}
//
//	public void setStartTime(LocalTime startTime) {
//		this.startTime = startTime;
//	}
//
//	public LocalTime getEndTime() {
//		return endTime;
//	}
//
//	public void setEndTime(LocalTime endTime) {
//		this.endTime = endTime;
//	}
//
//	public boolean isAvailiability() {
//		return availiability;
//	}
//
//	public void setAvailiability(boolean availiability) {
//		this.availiability = availiability;
//	}
//
//	public String getDuration() {
//		return duration;
//	}
//
//	public void setDuration(String duration) {
//		this.duration = duration;
//	}
//
//	public Sports getSports() {
//		return sports;
//	}
//
//	public void setSports(Sports sports) {
//		this.sports = sports;
//	}
//
//	@Override
//	public String toString() {
//		return "TimeSlots [slotsId=" + slotsId + ", startTime=" + startTime + ", endTime=" + endTime
//				+ ", availiability=" + availiability + ", duration=" + duration + ", sports=" + sports + "]";
//	}
//
//	public TimeSlots(int slotsId, LocalTime startTime, LocalTime endTime, boolean availiability, String duration,
//			Sports sports) {
//		super();
//		this.slotsId = slotsId;
//		this.startTime = startTime;
//		this.endTime = endTime;
//		this.availiability = availiability;
//		this.duration = duration;
//		this.sports = sports;
//	}
//	
//
//}
