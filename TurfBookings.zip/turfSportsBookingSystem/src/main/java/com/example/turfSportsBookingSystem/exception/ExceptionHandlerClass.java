package com.example.turfSportsBookingSystem.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ExceptionHandlerClass {

	
	@ExceptionHandler(value= {IdNotFoundException.class})
	public ResponseEntity<Object> handleIdNotFoundException(IdNotFoundException idNotFoundException){
		ErrorDetails idNotFoundExceptions = new ErrorDetails(idNotFoundException.getMessage(),LocalDateTime.now(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(idNotFoundExceptions,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(value= {AgeNotFoundException.class})
	public ResponseEntity<Object> handleAgeNotFoundException(AgeNotFoundException ageNotFoundException){
		ErrorDetails ageNotFoundExceotions = new ErrorDetails(ageNotFoundException.getMessage(),LocalDateTime.now(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ageNotFoundExceotions,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(value= {NameNotFoundException.class})
	public ResponseEntity<Object> handleNameNotFoundException(NameNotFoundException nameNotFoundException){
		ErrorDetails ageNotFoundExceptions = new ErrorDetails(nameNotFoundException.getMessage(),LocalDateTime.now(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ageNotFoundExceptions,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(value= {PasswordNotFoundException.class})
	public ResponseEntity<Object> handlePasswordNotFoundException(PasswordNotFoundException passwordNotFoundException){
		ErrorDetails passwordNotFoundExceptions = new ErrorDetails(passwordNotFoundException.getMessage(),LocalDateTime.now(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(passwordNotFoundExceptions,HttpStatus.NOT_FOUND);
	}



}
