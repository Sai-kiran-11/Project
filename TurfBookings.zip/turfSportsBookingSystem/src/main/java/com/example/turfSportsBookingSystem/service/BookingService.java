package com.example.turfSportsBookingSystem.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.turfSportsBookingSystem.entity.Bookings;
import com.example.turfSportsBookingSystem.entity.Sports;
import com.example.turfSportsBookingSystem.entity.TimeSlots;
import com.example.turfSportsBookingSystem.entity.Turf;
import com.example.turfSportsBookingSystem.entity.User;
import com.example.turfSportsBookingSystem.exception.IdNotFoundException;
import com.example.turfSportsBookingSystem.repository.BookingRepository;
import com.example.turfSportsBookingSystem.repository.SportsRepository;
import com.example.turfSportsBookingSystem.repository.TimeSlotRepository;
import com.example.turfSportsBookingSystem.repository.TurfRepository;
import com.example.turfSportsBookingSystem.repository.UserRepository;

@Service
public class BookingService {
	@Autowired
	BookingRepository bookingRepository;
	@Autowired
	TimeSlotRepository timeslotRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	TurfRepository turfRepository;
	@Autowired
	SportsRepository sportsRepository;

	public List<Bookings> getAll() {
		return bookingRepository.findAll();
	}

	public Optional<Bookings> findId(int id) {
		if( bookingRepository.findById(id).isEmpty()) {
			throw new IdNotFoundException("Requested id is not present");
		}
		return bookingRepository.findById(id);
	}

	public String bookTurf(int userId, int turfId, int sportId, int timeslotId) {

		
		////////////
		Optional<TimeSlots> timeslotAvailiablity = timeslotRepository.findById(timeslotId);
		if (timeslotAvailiablity.isPresent()) {
			TimeSlots timeSlot = timeslotAvailiablity.get();
			if (timeSlot.isAvailiability()) {
				Bookings bookings = new Bookings();
				Optional<Turf> turfs = turfRepository.findById(turfId);  /*.orElseThrow(() -> new RuntimeException("Turf not Found")); */
				 Turf turf = turfs.get();
				bookings.setTurfId(turfId);
				bookings.setTurfName(turf.getTurfName());
				Optional<Sports> sport = sportsRepository.findById(sportId);
				Sports sports = sport.get();
				bookings.setSportId(sportId);
				bookings.setSportName(sports.getSportName());;
				Optional<TimeSlots> timeslot = timeslotRepository.findById(timeslotId);
				TimeSlots timeslots= timeslot.get();
				bookings.setTimeslotId(timeslotId);
				bookings.setStartTime(timeslots.getStartTime());
				bookings.setEndTime(timeslots.getEndTime());
				bookings.setBookedDate(LocalDate.now());
				bookings.setBookedTime(LocalTime.now());
				bookings.setStatus("Booked");
				Optional<User> users = userRepository.findById(userId);
				User user = users.get();
				bookings.setUserId(user.getUserId());
				bookings.setUser(user);
				bookingRepository.save(bookings);
				timeSlot.setAvailiability(false);
				timeslotRepository.save(timeSlot);
				return "Successfully booked";
			} else {
				return "Time slot is not available for booking";
			}
		} else {
			return "Time Slot not Found";
		}

	}
	
	public String cancelBooking(int bookingId) {
		Optional<Bookings> bookingStatus = bookingRepository.findById(bookingId);
		if (bookingStatus.isPresent()) {
			Bookings bookings = bookingStatus.get();
			Optional<TimeSlots> TimeSlotId = timeslotRepository.findById(bookings.getTimeslotId());
			if (TimeSlotId.isPresent()) {
				TimeSlots timeslot = TimeSlotId.get();
				timeslot.setAvailiability(true);
				timeslotRepository.save(timeslot);
			}
			bookingRepository.deleteById(bookingId);
			return "Booking is Cancelled";
		} else {
			return "Booking not found by this id";
		}
	}

	public Bookings getbooking(int timeslotId) {
		return bookingRepository.findByTimeslotId(timeslotId);
	}

	public List<Bookings> getUserId(int userId) {
		return bookingRepository.findByUserId(userId);
	}


}

//latest deleted code
//boolean result = true;
//Optional<Turf> turfs = turfRepository.findById(turfId);/*.orElseThrow(() -> new RuntimeException("Turf not Found")); */
//Optional<User> user = userRepository.findById(userId);
//User userList = user.get();
//if(user.isPresent()) {
//if(turfs.isPresent()) {
//Turf turf = turfs.get();
//Set<Sports> sportsList = turf.getSports();
//Set<TimeSlots> timeSlotsList = new HashSet<>();
//Set<TimeSlots> timeslotsList = new HashSet<>();
//Sports selectedSport = null;
//for(Sports s : sportsList) {
//	if(s.getSport_id() == sportId) {
//		selectedSport =s;
//		timeSlotsList =  s.getTimeslots();
//		break;
//	}
//	}
//if(selectedSport !=null) {
//	timeslotsList = selectedSport.getTimeslots();
//}else {
//	return "Sports is not avaiable by sports id";
//}
//for(TimeSlots t:timeslotsList) {
//	if(t.getSlotsId() == timeslotId) {
//	if(t.isAvailiability()) {
//		Bookings bookings = new Bookings();
//		bookings.setTurf_id(turf.getTurf_id());
//		bookings.setTurf_Name(turf.getTurfName());
//		bookings.setSport_id(selectedSport.getSport_id());
//		bookings.setSport_Name(selectedSport.getSport_name());
//		bookings.setTimeSlot_id(t.getSlotsId());
//		bookings.setStart_time(t.getStartTime());
//		bookings.setEnd_time(t.getEndTime());
//		bookings.setStatus("Booked");
//		bookings.setBookedDate(LocalDate.now());
//		bookings.setBookedTime(LocalTime.now());
//		bookings.setUser(userList);
//		
//		t.setAvailiability(false);
//		
//		bookingRepository.save(bookings);
//		timeslotRepository.save(t);
//		return ("Succesfully booked");
//		}else {
//			result=false;
//		}
//	}else {
//		result=false;
//	}
//}if(result==false) {
//	return "Timeslots not found by this id";
//}
//
//}else {
//	return "Turf not found by this id";
//}
//}else {
//return "User not found by this id";
//}
//return "Given details are wrong";
//}
//
//
//Optional<Turf> turfs = turfRepository.findById(turfId);  /*.orElseThrow(() -> new RuntimeException("Turf not Found")); */
//Turf turf = turfs.get();
//
//List<Sports> sportsList = turf.getSports();
//List<TimeSlots> timeSlotsList = new ArrayList<>();
//
//for(Sports s: sportsList) {
//	if(s.getSport_id() == sportId) {
//		timeSlotsList=s.getSlots();
//		break;
//	}
//}
//for(TimeSlots t:timeSlotsList) {
//	if(t.isAvailiability()) {
//		
//		//write your own logic.......
//		
//		
//		t.setAvailiability(false);
//	}
//}
































//package com.example.turfSportsBookingSystem.service;
//
//import java.time.LocalDate;
//import java.time.LocalTime;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.turfSportsBookingSystem.entity.Bookings;
//import com.example.turfSportsBookingSystem.entity.Sports;
//import com.example.turfSportsBookingSystem.entity.TimeSlots;
//import com.example.turfSportsBookingSystem.entity.Turf;
//import com.example.turfSportsBookingSystem.entity.User;
//import com.example.turfSportsBookingSystem.repository.BookingRepository;
//import com.example.turfSportsBookingSystem.repository.SportsRepository;
//import com.example.turfSportsBookingSystem.repository.TimeSlotRepository;
//import com.example.turfSportsBookingSystem.repository.TurfRepository;
//import com.example.turfSportsBookingSystem.repository.UserRepository;
//
//@Service
//public class BookingService {
//	@Autowired
//	BookingRepository bookingRepository;
//	@Autowired
//	TimeSlotRepository timeslotRepository;
//	@Autowired
//	UserRepository userRepository;
//	@Autowired
//	TurfRepository turfRepository;
//	@Autowired
//	SportsRepository sportsRepository;
//
//	public List<Bookings> getAll() {
//		return bookingRepository.findAll();
//	}
//
//	public Optional<Bookings> findId(int id) {
//		return bookingRepository.findById(id);
//	}
//
//	public String bookTurf(int userId, int turfId, int sportId, int timeslotId) {
////		Optional<Turf> turfs = turfRepository.findById(turfId);/*.orElseThrow(() -> new RuntimeException("Turf not Found")); */
////		Optional<User> user = userRepository.findById(userId);
////		User userList = user.get();
////		if(user.isPresent()) {
////		if(turfs.isPresent()) {
////		Turf turf = turfs.get();
////		List<Sports> sportsList = turf.getSports();
////		List<TimeSlots> timeSlotsList = new ArrayList<>();
////		for(Sports s : sportsList) {
////			if(s.getSport_id() == sportId) {
////				timeSlotsList= s.getSlots();
////				for(TimeSlots t:timeSlotsList) {
////					if(t.isAvailiability()) {
////						Bookings bookings = new Bookings();
////						bookings.setTurf_id(turf.getTurf_id());
////						bookings.setTurf_Name(turf.getTurfName());
////						bookings.setSport_id(s.getSport_id());
////						bookings.setSport_Name(s.getSport_name());
////						bookings.setTimeSlot_id(t.getSlotsId());
////						bookings.setStart_time(t.getStartTime());
////						bookings.setEnd_time(t.getEndTime());
////						bookings.setBookedDate(LocalDate.now());
////						bookings.setBookedTime(LocalTime.now());
////						bookings.setUser(userList);
////						t.setAvailiability(false);
////						bookingRepository.save(bookings);
////						timeslotRepository.save(t);
////						
////					}else {
////						return "TimeSlots are not available by this Id";
////					}
////				}
////			}else {
////				return "Sports is not found by this id:";
////			}
////		}
////		}else {
////			return "Turf is not found by this id";
////		}
////		return "user is not found by this id";
////	}
////		return "given details are wrong";
////	}
////		Optional<TimeSlots> timeslotAvailiablity = timeslotRepository.findById(timeslotId);
////		if (timeslotAvailiablity.isPresent()) {
////			TimeSlots timeSlot = timeslotAvailiablity.get();
////			if (timeSlot.isAvailiability()) {
////				Bookings bookings = new Bookings();
////				Sports s= timeSlot.getSports();
////				Turf t = s.getTurf();
////				Optional<Turf> turfs = turfRepository.findById(turfId);  /*.orElseThrow(() -> new RuntimeException("Turf not Found")); */
////				 Turf turf = turfs.get();
////				bookings.setTurf_id(turfId);
////				bookings.setTurf_Name(turf.getTurfName());
////				Optional<Sports> sport = sportsRepository.findById(sportId);
////				Sports sports = sport.get();
////				bookings.setSport_id(sportId);
////				bookings.setSport_Name(sports.getSport_name());
////				Optional<TimeSlots> timeslot = timeslotRepository.findById(timeslotId);
////				TimeSlots timeslots= timeslot.get();
////				bookings.setTimeSlot_id(timeslotId);
////				bookings.setStart_time(timeslots.getStartTime());
////				bookings.setEnd_time(timeslots.getEndTime());
////				bookings.setBookedDate(LocalDate.now());
////				bookings.setBookedTime(LocalTime.now());
////				bookings.setStatus("Booked");
////				Optional<User> users = userRepository.findById(userId);
////				User user = users.get();
////				bookings.setUser(user);
////				bookingRepository.save(bookings);
////				timeSlot.setAvailiability(false);
////				timeslotRepository.save(timeSlot);
////				return "Successfully booked";
////			} else {
////				return "Time slot is not available for booking";
////			}
////		} else {
////			return "Time Slot not Found";
////		}
////
////	}
//		
//		Optional<TimeSlots> timeslotAvailiablity = timeslotRepository.findById(timeslotId);
//		if (timeslotAvailiablity.isPresent()) {
//			TimeSlots timeSlot = timeslotAvailiablity.get();
//			if (timeSlot.isAvailiability()) {
//				Bookings bookings = new Bookings();
//				Sports s= timeSlot.getSports();
//				Turf t = s.getTurf();
////				Optional<Turf> turfs = turfRepository.findById(turfId);  /*.orElseThrow(() -> new RuntimeException("Turf not Found")); */
////				 Turf turf = turfs.get();
//				bookings.setTurf_id(t.getTurf_id());
//				bookings.setTurf_Name(t.getTurfName());
////				Optional<Sports> sport = sportsRepository.findById(sportId);
////				Sports sports = sport.get();
//				bookings.setSport_id(s.getSport_id());
//				bookings.setSport_Name(s.getSport_name());
////				Optional<TimeSlots> timeslot = timeslotRepository.findById(timeslotId);
////				TimeSlots timeslots= timeslot.get();
//				bookings.setTimeSlot_id(timeSlot.getSlotsId());
//				bookings.setStart_time(timeSlot.getStartTime());
//				bookings.setEnd_time(timeSlot.getEndTime());
//				bookings.setBookedDate(LocalDate.now());
//				bookings.setBookedTime(LocalTime.now());
//				bookings.setStatus("Booked");
//				Optional<User> users = userRepository.findById(userId);
//				User user = users.get();
//				bookings.setUser(user);
//				bookingRepository.save(bookings);
//				timeSlot.setAvailiability(false);
//				timeslotRepository.save(timeSlot);
//				return "Successfully booked";
//			} else {
//				return "Time slot is not available for booking";
//			}
//		} else {
//			return "Time Slot not Found";
//		}
//
//	}
//	public String cancelBooking(int bookingId) {
//		Optional<Bookings> bookingStatus = bookingRepository.findById(bookingId);
//		if (bookingStatus.isPresent()) {
//			Bookings bookings = bookingStatus.get();
//			Optional<TimeSlots> TimeSlotId = timeslotRepository.findById(bookings.getTimeSlot_id());
//			if (TimeSlotId.isPresent()) {
//				TimeSlots timeslot = TimeSlotId.get();
//				timeslot.setAvailiability(true);
//				timeslotRepository.save(timeslot);
//			}
//			bookingRepository.deleteById(bookingId);
//			return "Booking is Cancelled";
//		} else {
//			return "Booking not found by this id";
//		}
//	}
//
//}
//
//
////
////
////Optional<Turf> turfs = turfRepository.findById(turfId);  /*.orElseThrow(() -> new RuntimeException("Turf not Found")); */
////Turf turf = turfs.get();
////
////List<Sports> sportsList = turf.getSports();
////List<TimeSlots> timeSlotsList = new ArrayList<>();
////
////for(Sports s: sportsList) {
////	if(s.getSport_id() == sportId) {
////		timeSlotsList=s.getSlots();
////		break;
////	}
////}
////for(TimeSlots t:timeSlotsList) {
////	if(t.isAvailiability()) {
////		
////		//write your own logic.......
////		
////		
////		t.setAvailiability(false);
////	}
////}