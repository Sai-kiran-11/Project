package com.example.turfSportsBookingSystem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.turfSportsBookingSystem.entity.Sports;
import com.example.turfSportsBookingSystem.entity.TimeSlots;
import com.example.turfSportsBookingSystem.service.TimeSlotService;



@RestController
@RequestMapping(value="/timeslot")
@CrossOrigin("*")
public class TimeSlotController {
	@Autowired
	TimeSlotService timeSlotService;
	
	@GetMapping("/all")
	public List<TimeSlots> getAll(){
		return timeSlotService.findAll();
	}
	@GetMapping("/{id}")
	public Optional<TimeSlots> getById(@PathVariable int id){
		Optional<TimeSlots> timeSlotsById = timeSlotService.getById(id);
		return timeSlotsById;
	}
	@GetMapping("/getall/sportsId/{sportsid}")
	public List<TimeSlots> getBySportsId(@PathVariable int sportsid){
		List<TimeSlots> timeSlotsBySportsId = timeSlotService.getBySportsId(sportsid);
		return timeSlotsBySportsId;
	}
	@GetMapping("/getby/duration/{duration}")
	public List<TimeSlots> getByDuration(@PathVariable String duration){
		List<TimeSlots> timeSlotsByDuration = timeSlotService.getByDuration(duration);
		return timeSlotsByDuration;
	}

	@PostMapping("/post")
	public TimeSlots add(@RequestBody TimeSlots timeSlots){
		return timeSlotService.addTimeSlot(timeSlots);
	}
	@PutMapping("/update/id/{id}/starttime/{starttime}/endtime/{endtime}/duration/{duration}")
	public String updateStartTimeEndTimeDuration(@PathVariable int id,@PathVariable String starttime,@PathVariable String endtime,@PathVariable String duration) {
		String status = timeSlotService.updateStartTimeEndTimeDuration(id,starttime,endtime,duration);
		return status;
	}
	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable int id) {
		timeSlotService.deleteTimeSlotById(id);
	}
	

}
