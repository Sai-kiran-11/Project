package com.example.turfSportsBookingSystem.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

public class ErrorDetails {
	private final String message;
	private final LocalDateTime timeStamp;
	private final HttpStatus httpStatus;
	public ErrorDetails(String message, LocalDateTime timeStamp, HttpStatus httpStatus) {
		super();
		this.message = message;
		this.timeStamp = timeStamp;
		this.httpStatus = httpStatus;
	}
	public String getMessage() {
		return message;
	}
	public LocalDateTime getTimeStamp() {
		return timeStamp;
	}
	public HttpStatus getHttpStatus() {
		return httpStatus;
	}
		
}
