package com.example.turfSportsBookingSystem.service;

import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.turfSportsBookingSystem.entity.Sports;
import com.example.turfSportsBookingSystem.entity.TimeSlots;
import com.example.turfSportsBookingSystem.entity.Turf;
import com.example.turfSportsBookingSystem.exception.IdNotFoundException;
import com.example.turfSportsBookingSystem.repository.SportsRepository;
import com.example.turfSportsBookingSystem.repository.TimeSlotRepository;



@Service
public class TimeSlotService {
	@Autowired
	TimeSlotRepository timeSlotRepository;
	@Autowired
	SportsRepository sportsRepository;
	
	public List<TimeSlots> findAll() {
		return timeSlotRepository.findAll();
	}

	public TimeSlots addTimeSlot(TimeSlots timeSlots) {
		return timeSlotRepository.save(timeSlots);
	}
	public Optional<TimeSlots> getById(int id){
		if(timeSlotRepository.findById(id).isEmpty()) {
			throw new IdNotFoundException("Requested Id is not present");
		}
		return timeSlotRepository.findById(id);
	}
	public String updateStartTimeEndTimeDuration(int id,String starttime,String endtime,String duration) {
		Optional<TimeSlots> timeSlotId = timeSlotRepository.findById(id);
		if(timeSlotId.isPresent()) {
			TimeSlots timeSlots = timeSlotId.get();
			LocalTime start_time = LocalTime.parse(starttime);
			LocalTime end_time = LocalTime.parse(endtime);
			timeSlots.setStartTime(start_time);
			timeSlots.setEndTime(end_time);
			timeSlots.setDuration(duration);
			timeSlotRepository.save(timeSlots);
			return "All the values are updated successfully";
		}else {
			return "TimeSlots for this id is not found";
		}
	}
	public void deleteTimeSlotById(int id) {
		 timeSlotRepository.deleteById(id);
	}

	public List<TimeSlots> getBySportsId(int sportsid) {
		Optional<Sports> sportsId = sportsRepository.findById(sportsid);
		
		List<TimeSlots> timeSlots = null;
		if(sportsId.isPresent()) {
			Sports sports = sportsId.get();
			timeSlots = sports.getSlots();
		}
		return timeSlots;
	}

	public List<TimeSlots> getByDuration(String duration) {
		return timeSlotRepository.findByDuration(duration);
	}


}
