package com.example.turfSportsBookingSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.example.turfSportsBookingSystem.entity.Turf;

public interface TurfRepository  extends JpaRepository<Turf,Integer>{

	List<Turf> findByTurfName(String name);
	List<Turf> findByTurfLocation(String location);
}
