package com.example.turfSportsBookingSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.turfSportsBookingSystem.entity.Admin;


public interface AdminRepository  extends JpaRepository<Admin,Integer>{
	public List<Admin> findByName(String name);
	public List<Admin> findByPassword(String password);
	public Admin findByEmail(String email);
}

