package com.example.turfSportsBookingSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TurfSportsBookingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TurfSportsBookingSystemApplication.class, args);
	}

}
