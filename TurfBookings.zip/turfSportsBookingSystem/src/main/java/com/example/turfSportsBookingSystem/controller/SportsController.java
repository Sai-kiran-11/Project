package com.example.turfSportsBookingSystem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.turfSportsBookingSystem.entity.Sports;
import com.example.turfSportsBookingSystem.service.SportsService;


@RestController
@RequestMapping(value="/sports")
@CrossOrigin("*")
public class SportsController {
	@Autowired
	SportsService sportsService;
	
	@GetMapping("/all")
	public List<Sports> getAll(){
		return sportsService.findAll();
	}
	@GetMapping("/id/{id}")
	public Optional<Sports> getById(@PathVariable int id){
		Optional<Sports> sportById =  sportsService.getById(id);
		return sportById;
	}
	@GetMapping("/getall/turfid/{id}")
	public List<Sports> getByTurfId(@PathVariable int id){
		List<Sports> sportById =  sportsService.getByTurfId(id);
		return sportById;
	}
	@GetMapping("/getby/sportsName/{sportsname}")
	public List<Sports> getBySportName(@PathVariable String sportsname){
		List<Sports> sportByName= sportsService.getBySportsName(sportsname);
		return sportByName;
	}
	@GetMapping("/getby/sportpricePerHour/{pricePerHour}")
	public List<Sports> getBySportsPricePerHour(@PathVariable String pricePerHour){
		return sportsService.getBySportsPricePerHour(pricePerHour);
	}
	@PostMapping("/post")
	public Sports add(@RequestBody Sports sports){
		return sportsService.addSports(sports);
	}
	@PutMapping("/update/name/{id}/{name}")
	public String updateName(@PathVariable int id,@PathVariable String name) {
		String status = sportsService.updateName(id,name);
		return status;
	}
	@PutMapping("/update/PricePerHour/{id}/{PricePerHour}")
	public String updatePricePerHour(@PathVariable int id,@PathVariable String PricePerHour) {
		String status = sportsService.updatePricePerHour(id,PricePerHour);
		return status;
	}
	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable int id) {
		sportsService.deleteBySportsId(id);
	}

}
