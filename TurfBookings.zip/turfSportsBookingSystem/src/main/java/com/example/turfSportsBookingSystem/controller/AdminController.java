package com.example.turfSportsBookingSystem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.turfSportsBookingSystem.entity.Admin;
import com.example.turfSportsBookingSystem.service.AdminService;



@RestController
@RequestMapping(value="/admin")
@CrossOrigin("*")
public class AdminController {
	@Autowired
	AdminService adminService;
	
	@GetMapping("/all")
	public List<Admin> getAll(){
		return adminService.findAll();
	}
	@GetMapping("/id/{id}")
	public Optional<Admin> getById(@PathVariable int id){
		Optional<Admin> adminByid = adminService.findById(id);
		
		return adminByid;
	}
	@GetMapping("/search/name/{name}")
	public List<Admin> getByName(@PathVariable String name){
		List<Admin> adminByName = adminService.findByName(name);
		return adminByName;
	}
	@GetMapping("/getby/email/{email}")
	public Admin getByEmail(@PathVariable String email) {
		return adminService.getByEmail(email);
	}
	@GetMapping("/search/password/{password}")
	public List<Admin> getByPassword(@PathVariable String password){
		List<Admin> adminByPassword = adminService.findByPassword(password);
		return adminByPassword;
	}
	@PostMapping("/post")
	public Admin add(@RequestBody Admin admin){
		return adminService.addAdmin(admin);
	}
	@PutMapping("/update/name/{id}/{password}/{newName}")
	public String updateAdminName(@PathVariable int id,@PathVariable String password,@PathVariable String newName) {
		String status ;
		status = adminService.updateAdminName(id,password,newName);
		return status;
	}
	@PutMapping("/update/password/{id}/{Oldpassword}/{Newpassword}")
	public String updateAdminPassword(@PathVariable int id,@PathVariable String Oldpassword,@PathVariable String Newpassword) {
		String status ;
		status = adminService.updateAdminPassword(id,Oldpassword,Newpassword);
		return status;
	}
	@DeleteMapping("/delete/{id}")
	public void deleteById(@PathVariable int id) {
		 adminService.deleteAdminById(id);
	}
}
