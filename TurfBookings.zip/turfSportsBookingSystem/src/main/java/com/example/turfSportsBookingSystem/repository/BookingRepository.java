package com.example.turfSportsBookingSystem.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.turfSportsBookingSystem.entity.Bookings;



public interface BookingRepository  extends JpaRepository<Bookings,Integer> {

	Bookings findByTimeslotId(int timeslotId);

	List<Bookings> findByUserId(int userId);

}
