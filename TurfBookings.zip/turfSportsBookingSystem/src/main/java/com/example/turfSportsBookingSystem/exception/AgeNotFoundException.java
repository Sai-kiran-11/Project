package com.example.turfSportsBookingSystem.exception;

public class AgeNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	public AgeNotFoundException(String message)
	{
		super(message);
	}
}
