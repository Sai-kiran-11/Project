package com.example.turfSportsBookingSystem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.turfSportsBookingSystem.entity.Turf;
import com.example.turfSportsBookingSystem.service.TurfService;



@RestController
@RequestMapping(value="/turf")
@CrossOrigin("*")
public class TurfController {
	@Autowired
	TurfService turfService;
	
	@GetMapping("/all")
	public List<Turf> getAll(){
		return turfService.findAll();
	}
	@GetMapping("get/{id}")
	public Optional<Turf> getById(@PathVariable int id){
		Optional<Turf> turf = turfService.getById(id);
		return turf;
	}
	@GetMapping("get/name/{name}")
	public List<Turf> getByName(@PathVariable String name){
		List<Turf> turfByName =  turfService.getByName(name);
				return turfByName;
	}
	@GetMapping("/get/location/{location}")
	public List<Turf> getByTurfLocation(@PathVariable String location){
		List<Turf> turfByLocation = turfService.getByTurfLocation(location);
		return turfByLocation ;
	}
	@PostMapping("/post")
	public Turf add(@RequestBody Turf turf){
		return turfService.addTurf(turf);
	}
	@PutMapping("/update/id/{id}/name/{name}")
	public String updateName(@PathVariable int id,@PathVariable String name) {
		String status = turfService.updateName(id,name);
		return status;
	}
	@PutMapping("/update/id/{id}/location/{location}")
	public String updateLocation(@PathVariable int id,@PathVariable String location) {
		String status= turfService.updateLocation(id,location);
		return status;
	}
	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable int id) {
		turfService.deleteTurf(id);
	}

}