package com.example.turfSportsBookingSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.turfSportsBookingSystem.entity.Sports;

public interface SportsRepository  extends JpaRepository<Sports,Integer>{
	List<Sports> findBySportName(String sportname);
	List<Sports> findByPricePerHour(String pricePerHour);
}
