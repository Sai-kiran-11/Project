package com.example.turfSportsBookingSystem.entity;

import java.time.LocalDate;
import java.time.LocalTime;

import org.springframework.stereotype.Component;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Bookings {
	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	private int id;

	private String status;
	
	private int turfId;
	
	private String turfName;
	
	private int sportId;
	
	private String sportName;
	
	
	private int timeslotId;
	
	private LocalTime startTime;
	 
	private LocalTime EndTime;
	
	private LocalDate BookedDate;
	
	private LocalTime BookedTime;
	
	private int userId;
	
	@ManyToOne
	private User user;
	
	public Bookings() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getTurfId() {
		return turfId;
	}

	public void setTurfId(int turfId) {
		this.turfId = turfId;
	}

	public String getTurfName() {
		return turfName;
	}

	public void setTurfName(String turfName) {
		this.turfName = turfName;
	}

	public int getSportId() {
		return sportId;
	}

	public void setSportId(int sportId) {
		this.sportId = sportId;
	}

	public String getSportName() {
		return sportName;
	}

	public void setSportName(String sportName) {
		this.sportName = sportName;
	}

	public int getTimeslotId() {
		return timeslotId;
	}

	public void setTimeslotId(int timeslotId) {
		this.timeslotId = timeslotId;
	}

	public LocalTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}

	public LocalTime getEndTime() {
		return EndTime;
	}

	public void setEndTime(LocalTime endTime) {
		EndTime = endTime;
	}

	public LocalDate getBookedDate() {
		return BookedDate;
	}

	public void setBookedDate(LocalDate bookedDate) {
		BookedDate = bookedDate;
	}

	public LocalTime getBookedTime() {
		return BookedTime;
	}

	public void setBookedTime(LocalTime bookedTime) {
		BookedTime = bookedTime;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Bookings [id=" + id + ", status=" + status + ", turfId=" + turfId + ", turfName=" + turfName
				+ ", sportId=" + sportId + ", sportName=" + sportName + ", timeslotId=" + timeslotId + ", startTime="
				+ startTime + ", EndTime=" + EndTime + ", BookedDate=" + BookedDate + ", BookedTime=" + BookedTime
				+ ", userId=" + userId + ", user=" + user + "]";
	}

	public Bookings(String status, int turfId, String turfName, int sportId, String sportName, int timeslotId,
			LocalTime startTime, LocalTime endTime, LocalDate bookedDate, LocalTime bookedTime, int userId) {
		super();
		this.status = status;
		this.turfId = turfId;
		this.turfName = turfName;
		this.sportId = sportId;
		this.sportName = sportName;
		this.timeslotId = timeslotId;
		this.startTime = startTime;
		EndTime = endTime;
		BookedDate = bookedDate;
		BookedTime = bookedTime;
		this.userId = userId;
	}
	
	
}
//	
//	@Id
//	@GeneratedValue(strategy =  GenerationType.IDENTITY)
//	private int id;
//
//	private String status;
//	
//	private int turf_id;
//	
//	private String turf_Name;
//	
//	private int sport_id;
//	
//	private String sport_Name;
//	
//	
//	private int timeSlot_id;
//	
//	private LocalTime start_time;
//	 
//	private LocalTime End_time;
//	
//	private LocalDate BookedDate;
//	
//	private LocalTime BookedTime;
//	
//	@ManyToOne
//	private User user;
//	
//	public Bookings() {
//		
//	}
////	@Override
////	public String toString() {
////		return "Bookings [id=" + id + ", status=" + status + ", turf_id=" + turf_id + ", sport_id=" + sport_id
////				+ ", timeSlot_id=" + timeSlot_id + ", todayDate=" + todayDate + ", user=" + user + "]";
////	}
////	public Bookings(String status, int turf_id, int sport_id, int timeSlot_id, LocalDate todayDate) {
////		super();
////		this.status = status;
////		this.turf_id = turf_id;
////		this.sport_id = sport_id;
////		this.timeSlot_id = timeSlot_id;
////		this.todayDate = todayDate;
////	}
////
////
////	public User getUser() {
////		return user;
////	}
////
////	public void setUser(User user) {
////		this.user = user;
////	}
////
////	public int getId() {
////		return id;
////	}
////
////	public void setId(int id) {
////		this.id = id;
////	}
////
////	public String getStatus() {
////		return status;
////	}
////
////	public void setStatus(String status) {
////		this.status = status;
////	}
////
////	public int getTurf_id() {
////		return turf_id;
////	}
////
////	public void setTurf_id(int turf_id) {
////		this.turf_id = turf_id;
////	}
////
////	public int getSport_id() {
////		return sport_id;
////	}
////
////	public void setSport_id(int sport_id) {
////		this.sport_id = sport_id;
////	}
////
////	public int getTimeSlot_id() {
////		return timeSlot_id;
////	}
////
////	public void setTimeSlot_id(int timeSlot_id) {
////		this.timeSlot_id = timeSlot_id;
////	}
////
////	public LocalDate getTodayDate() {
////		return todayDate;
////	}
////
////	public void setTodayDate(LocalDate todayDate) {
////		this.todayDate = todayDate;
////	}
////////////////////////////////////////////////////////
////	public int getId() {
////		return id;
////	}
////
////	@Override
////	public String toString() {
////		return "Bookings [id=" + id + ", status=" + status + ", turf_id=" + turf_id + ", turf_Name=" + turf_Name
////				+ ", sport_id=" + sport_id + ", sport_Name=" + sport_Name + ", timeSlot_id=" + timeSlot_id
////				+ ", start_time=" + start_time + ", End_time=" + End_time + ", BookedDate=" + BookedDate + ", user="
////				+ user + "]";
////	}
////
////	public void setId(int id) {
////		this.id = id;
////	}
////
////	public String getStatus() {
////		return status;
////	}
////
////	public void setStatus(String status) {
////		this.status = status;
////	}
////
////	public int getTurf_id() {
////		return turf_id;
////	}
////
////	public void setTurf_id(int turf_id) {
////		this.turf_id = turf_id;
////	}
////
////	public String getTurf_Name() {
////		return turf_Name;
////	}
////
////	public void setTurf_Name(String turf_Name) {
////		this.turf_Name = turf_Name;
////	}
////
////	public int getSport_id() {
////		return sport_id;
////	}
////
////	public void setSport_id(int sport_id) {
////		this.sport_id = sport_id;
////	}
////
////	public String getSport_Name() {
////		return sport_Name;
////	}
////
////	public void setSport_Name(String sport_Name) {
////		this.sport_Name = sport_Name;
////	}
////
////	public int getTimeSlot_id() {
////		return timeSlot_id;
////	}
////
////	public void setTimeSlot_id(int timeSlot_id) {
////		this.timeSlot_id = timeSlot_id;
////	}
////
////	public LocalTime getStart_time() {
////		return start_time;
////	}
////
////	public void setStart_time(LocalTime start_time) {
////		this.start_time = start_time;
////	}
////
////	public LocalTime getEnd_time() {
////		return End_time;
////	}
////
////	public void setEnd_time(LocalTime end_time) {
////		End_time = end_time;
////	}
////
////	public LocalDate getBookedDate() {
////		return BookedDate;
////	}
////
////	public void setBookedDate(LocalDate bookedDate) {
////		BookedDate = bookedDate;
////	}
////
////	public User getUser() {
////		return user;
////	}
////
////	public void setUser(User user) {
////		this.user = user;
////	}
////	public Bookings(String status, int turf_id, String turf_Name, int sport_id, String sport_Name, int timeSlot_id,
////			LocalTime start_time, LocalTime end_time, LocalDate bookedDate) {
////		super();
////		this.status = status;
////		this.turf_id = turf_id;
////		this.turf_Name = turf_Name;
////		this.sport_id = sport_id;
////		this.sport_Name = sport_Name;
////		this.timeSlot_id = timeSlot_id;
////		this.start_time = start_time;
////		End_time = end_time;
////		BookedDate = bookedDate;
////	}
//
//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public String getStatus() {
//		return status;
//	}
//
//	public void setStatus(String status) {
//		this.status = status;
//	}
//
//	public int getTurf_id() {
//		return turf_id;
//	}
//
//	public void setTurf_id(int turf_id) {
//		this.turf_id = turf_id;
//	}
//
//	public String getTurf_Name() {
//		return turf_Name;
//	}
//
//	public void setTurf_Name(String turf_Name) {
//		this.turf_Name = turf_Name;
//	}
//
//	public int getSport_id() {
//		return sport_id;
//	}
//
//	public void setSport_id(int sport_id) {
//		this.sport_id = sport_id;
//	}
//
//	public String getSport_Name() {
//		return sport_Name;
//	}
//
//	public void setSport_Name(String sport_Name) {
//		this.sport_Name = sport_Name;
//	}
//
//	public int getTimeSlot_id() {
//		return timeSlot_id;
//	}
//
//	public void setTimeSlot_id(int timeSlot_id) {
//		this.timeSlot_id = timeSlot_id;
//	}
//
//	public LocalTime getStart_time() {
//		return start_time;
//	}
//
//	public void setStart_time(LocalTime start_time) {
//		this.start_time = start_time;
//	}
//
//	public LocalTime getEnd_time() {
//		return End_time;
//	}
//
//	public void setEnd_time(LocalTime end_time) {
//		End_time = end_time;
//	}
//
//	public LocalDate getBookedDate() {
//		return BookedDate;
//	}
//
//	public void setBookedDate(LocalDate bookedDate) {
//		BookedDate = bookedDate;
//	}
//
//	public LocalTime getBookedTime() {
//		return BookedTime;
//	}
//
//	public void setBookedTime(LocalTime bookedTime) {
//		BookedTime = bookedTime;
//	}
//
//	public User getUser() {
//		return user;
//	}
//
//	public void setUser(User user) {
//		this.user = user;
//	}
//
//	@Override
//	public String toString() {
//		return "Bookings [id=" + id + ", status=" + status + ", turf_id=" + turf_id + ", turf_Name=" + turf_Name
//				+ ", sport_id=" + sport_id + ", sport_Name=" + sport_Name + ", timeSlot_id=" + timeSlot_id
//				+ ", start_time=" + start_time + ", End_time=" + End_time + ", BookedDate=" + BookedDate
//				+ ", BookedTime=" + BookedTime + ", user=" + user + "]";
//	}
//	public Bookings(String status, int turf_id, String turf_Name, int sport_id, String sport_Name, int timeSlot_id,
//			LocalTime start_time, LocalTime end_time, LocalDate bookedDate, LocalTime bookedTime) {
//		super();
//		this.status = status;
//		this.turf_id = turf_id;
//		this.turf_Name = turf_Name;
//		this.sport_id = sport_id;
//		this.sport_Name = sport_Name;
//		this.timeSlot_id = timeSlot_id;
//		this.start_time = start_time;
//		End_time = end_time;
//		BookedDate = bookedDate;
//		BookedTime = bookedTime;
//	}
//	
//
//	
//
//}