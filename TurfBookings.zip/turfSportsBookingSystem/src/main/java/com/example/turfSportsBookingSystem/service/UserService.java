package com.example.turfSportsBookingSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.turfSportsBookingSystem.entity.User;
import com.example.turfSportsBookingSystem.exception.AgeNotFoundException;
import com.example.turfSportsBookingSystem.exception.IdNotFoundException;
import com.example.turfSportsBookingSystem.exception.NameNotFoundException;
import com.example.turfSportsBookingSystem.repository.UserRepository;


@Service
public class UserService {
	@Autowired
	UserRepository userRepository;
	
	public List<User> findAll(){
		return userRepository.findAll();
	}
	public Optional<User> getById(int id){
		if(userRepository.findById(id).isEmpty()) {
			throw new IdNotFoundException("Requested Id is not present");
		}
		return userRepository.findById(id);
	}
	public List<User> findByUserName(String name){
		if( userRepository.findByUserName(name).isEmpty()) {
			throw new NameNotFoundException("Requested name is not present");
		}
		return userRepository.findByUserName(name);
	}
	public List<User> findByAge(int age){
		if(userRepository.findByAge(age).isEmpty()) {
			throw new AgeNotFoundException("Requested age is not present");
		}
		return userRepository.findByAge(age);
	}
	public User add(User user) {
		return userRepository.save(user);
	}
	public String updateName(int id,String password,String name) {
		Optional<User> userId = userRepository.findById(id);
		if(userId.isPresent()) {
			User user = userId.get();
			if(user.getPassword().equals(password)) {
				user.setUserName(name);
				userRepository.save(user);
				return "User Name Updated succesfully";
			}else {
				return "Password is not correct";
			}
		}else {
			return "User not Found By this Id";
		}
	}
	public String updateAge(@PathVariable int id,@PathVariable String password,@PathVariable int age) {
		Optional<User> userId = userRepository.findById(id);
		if(userId.isPresent()) {
			User user = userId.get();
			if(user.getPassword().equals(password)) {
				user.setAge(age);
				userRepository.save(user);
				return "Age is updated Successfully";
			}else {
				return "Password is not correct";
			}
			
		}else {
			return "User not found by this Id";
		}
	}
	public String updatePassword(int id,String oldpassword,String newpassword) {
		Optional<User> userId = userRepository.findById(id);
		if(userId.isPresent()) {
			User user = userId.get();
			if(user.getPassword().equals(oldpassword)) {
				user.setPassword(newpassword);
				userRepository.save(user);
				return "Password is Updated Successfully";
			}else {
				return "Given Oldpassword is not correct";
			}
		}else {
			return "User not found by this Id";
		}
	}
	public void delete(int id) {
		userRepository.deleteById(id);
	}
	public User findByEmail(String email) {
		return userRepository.findByEmail(email);
	}

}
