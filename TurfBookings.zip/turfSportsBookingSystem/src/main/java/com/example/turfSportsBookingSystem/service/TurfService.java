package com.example.turfSportsBookingSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.turfSportsBookingSystem.entity.Sports;
import com.example.turfSportsBookingSystem.entity.Turf;
import com.example.turfSportsBookingSystem.exception.IdNotFoundException;
import com.example.turfSportsBookingSystem.repository.TurfRepository;



@Service
public class TurfService {
	@Autowired
	TurfRepository turfRepository;

	public List<Turf> findAll() {
		return turfRepository.findAll();
	}
	public Optional<Turf> getById(int id){
		
		 if(turfRepository.findById(id).isEmpty()){
			 throw new IdNotFoundException("Requested Id is not Present");
		 }
		 return turfRepository.findById(id);
	}
	public List<Turf> getByName(String name){
		return turfRepository.findByTurfName(name);
	}
	public List<Turf> getByTurfLocation(String location){
		return turfRepository.findByTurfLocation(location);
	}

	public Turf addTurf(Turf turf) {
		return turfRepository.save(turf);
	}
	public String updateName(int id,String name) {
		Optional<Turf> turfId = turfRepository.findById(id);
		if(turfId.isPresent()) {
			Turf turf = turfId.get();
			turf.setTurfName(name);
			turfRepository.save(turf);
			return "Turf name Updated Successfully";
		}else {
			return "Turf id is not found";
		}
	}
	public String updateLocation(int id,String location) {
		Optional<Turf> turfid = turfRepository.findById(id);
		if(turfid.isPresent()) {
			Turf turf = turfid.get();
			turf.setTurfLocation(location);
			turfRepository.save(turf);
			return "Location of the turf is Successfully changed";
		}else {
			return "Turf id is not found";
		}
	}

	public void deleteTurf(int id) {
		turfRepository.deleteById(id); 
	}

	

}
