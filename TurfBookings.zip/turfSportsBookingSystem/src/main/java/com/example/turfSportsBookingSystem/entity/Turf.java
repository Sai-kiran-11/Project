package com.example.turfSportsBookingSystem.entity;

import java.util.ArrayList;
import java.util.List;


import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Turf {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int turfId;
	
	private String turfName;
	
	private String turfLocation;
	
	@OneToMany(mappedBy = "turf", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Sports> sports =  new ArrayList<>();



	public Turf() {
		super();
	}



	public int getTurfId() {
		return turfId;
	}



	public void setTurfId(int turfId) {
		this.turfId = turfId;
	}



	public String getTurfName() {
		return turfName;
	}



	public void setTurfName(String turfName) {
		this.turfName = turfName;
	}



	public String getTurfLocation() {
		return turfLocation;
	}



	public void setTurfLocation(String turfLocation) {
		this.turfLocation = turfLocation;
	}



	public List<Sports> getSports() {
		return sports;
	}



	public void setSports(List<Sports> sports) {
		this.sports = sports;
	}



	@Override
	public String toString() {
		return "Turf [turfId=" + turfId + ", turfName=" + turfName + ", turfLocation=" + turfLocation + ", sports="
				+ sports + "]";
	}



	public Turf(String turfName, String turfLocation, List<Sports> sports) {
		super();
		this.turfName = turfName;
		this.turfLocation = turfLocation;
		this.sports = sports;
	}

	


	

}



































































//package com.example.turfSportsBookingSystem.entity;
//
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//
//import com.fasterxml.jackson.annotation.JsonIgnore;
//
//import jakarta.persistence.CascadeType;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.JoinColumn;
//import jakarta.persistence.JoinTable;
//import jakarta.persistence.ManyToMany;
//import jakarta.persistence.ManyToOne;
//import jakarta.persistence.OneToMany;
//
//@Entity
//public class Turf {
//	@Id
////	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private int Turf_id;
//	
//	private String TurfName;
//	
//	private String TurfLocation;
//	
////	@ManyToMany(cascade = CascadeType.ALL)
//	@ManyToMany
//	@JoinTable(name ="turf_sports", 
//	joinColumns = @JoinColumn(name="turf_id"),
//	inverseJoinColumns = @JoinColumn(name="sports_id"))
//	private Set<Sports> sports = new HashSet<>();
//
//	public Turf() {
//		super();
//	}
//
//	public int getTurf_id() {
//		return Turf_id;
//	}
//
//	public void setTurf_id(int turf_id) {
//		Turf_id = turf_id;
//	}
//
//	public String getTurfName() {
//		return TurfName;
//	}
//
//	public void setTurfName(String turfName) {
//		TurfName = turfName;
//	}
//
//	public String getTurfLocation() {
//		return TurfLocation;
//	}
//
//	public void setTurfLocation(String turfLocation) {
//		TurfLocation = turfLocation;
//	}
//
//	public Set<Sports> getSports() {
//		return sports;
//	}
//
//	public void setSports(Set<Sports> sports) {
//		this.sports = sports;
//	}
//
//	public Turf(int turf_id, String turfName, String turfLocation) {
//		super();
//		Turf_id = turf_id;
//		TurfName = turfName;
//		TurfLocation = turfLocation;
//	}
//
//	@Override
//	public String toString() {
//		return "Turf [Turf_id=" + Turf_id + ", TurfName=" + TurfName + ", TurfLocation=" + TurfLocation + ", sports="
//				+ sports + "]";
//	}
//	
//
//
//	
//	
//
//}

































//package com.example.turfSportsBookingSystem.entity;
//
//import java.util.ArrayList;
//import java.util.List;
//
//
//import com.fasterxml.jackson.annotation.JsonIgnore;
//
//import jakarta.persistence.CascadeType;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.OneToMany;
//
//@Entity
//public class Turf {
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private int Turf_id;
//	
//	private String TurfName;
//	
//	private String TurfLocation;
//	
//	@OneToMany(mappedBy = "turf", cascade = CascadeType.ALL)
//	@JsonIgnore
//	private List<Sports> sports =  new ArrayList<>();
//
//
//	public Turf(int turf_id, String turfName, String turfLocation) {
//		super();
//		Turf_id = turf_id;
//		TurfName = turfName;
//		TurfLocation = turfLocation;
//	}
//
//
//	@Override
//	public String toString() {
//		return "Turf [Turf_id=" + Turf_id + ", TurfName=" + TurfName + ", TurfLocation=" + TurfLocation + ", sports="
//				+ sports + "]";
//	}
//
//
//	public Turf() {
//		
//	}
//
//
//	public int getTurf_id() {
//		return Turf_id;
//	}
//
//
//	public void setTurf_id(int turf_id) {
//		Turf_id = turf_id;
//	}
//
//
//	public String getTurfName() {
//		return TurfName;
//	}
//
//
//	public void setTurfName(String turfName) {
//		TurfName = turfName;
//	}
//
//
//	public String getTurfLocation() {
//		return TurfLocation;
//	}
//
//
//	public void setTurfLocation(String turfLocation) {
//		TurfLocation = turfLocation;
//	}
//
//
//	public List<Sports> getSports() {
//		return sports;
//	}
//
//
//	public void setSports(List<Sports> sports) {
//		this.sports = sports;
//	}
//	
//
//}