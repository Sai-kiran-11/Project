package com.example.turfSportsBookingSystem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.turfSportsBookingSystem.entity.User;
import com.example.turfSportsBookingSystem.service.UserService;



@RestController
@RequestMapping(value="/user")
@CrossOrigin("*")
public class UserController {
	@Autowired
	UserService userService;
	
	@GetMapping("/all")
	public List<User> getAll(){
		return userService.findAll();
	}
	@GetMapping("/{id}")
	public Optional<User> getById(@PathVariable int id){
		Optional<User> getById = userService.getById(id);
		return getById;
	}
	@GetMapping("get/name/{name}")
	public List<User> getByName(@PathVariable String name) {
		return userService.findByUserName(name);
	}
	@GetMapping("get/age/{age}")
	public List<User> getByName(@PathVariable int age) {
		return userService.findByAge(age);
	}
	@GetMapping("get/email/{email}")
	public User findById(@PathVariable String email){
		return userService.findByEmail(email);
		
		
	}
	@PostMapping("/post")
	public User add(@RequestBody User user) {
		return userService.add(user);
	}
	@PutMapping("/update/id/{id}/password/{password}/name/{name}")
	public String updateName(@PathVariable int id,@PathVariable String password,@PathVariable String name) {
		String status = userService.updateName(id,password,name);
		return status;
	}
	@PutMapping("/update/id/{id}/password/{password}/age/{age}")
	public String updateAge(@PathVariable int id,@PathVariable String password,@PathVariable int age) {
		String status = userService.updateAge(id,password,age);
		return status;
	}
	@PutMapping("/update/id/{id}/Oldpassword/{oldpassword}/Newpassword/{newpassword}")
	public String updatePassword(@PathVariable int id,@PathVariable String oldpassword,@PathVariable String newpassword) {
		String status = userService.updatePassword(id,oldpassword,newpassword);
		return status;
	}
	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable int id) {
		userService.delete(id);
	}
	

}
