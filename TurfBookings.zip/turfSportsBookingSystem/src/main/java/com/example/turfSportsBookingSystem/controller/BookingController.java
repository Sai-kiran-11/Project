package com.example.turfSportsBookingSystem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.turfSportsBookingSystem.entity.Bookings;
import com.example.turfSportsBookingSystem.service.BookingService;



@RestController
@RequestMapping(value="/booking")
@CrossOrigin("*")

//@ComponentScan(basePackages = "com.booking.demooo.entity")
public class BookingController {
	@Autowired
	BookingService bookingService;

	@GetMapping("/all")
	public List<Bookings> getAll(){
		return bookingService.getAll();
	}
	@GetMapping("/id/{id}")
	public Optional<Bookings> findById(@PathVariable int id){
		Optional<Bookings> bookingId = bookingService.findId(id);
		return bookingId;
	}
	@GetMapping("/userId/{userId}")
	public List<Bookings> getByUserId(@PathVariable int userId) {
		return bookingService.getUserId(userId);
	}
	@DeleteMapping("/delete/{bookingid}")
	public String cancelBooking(@PathVariable int bookingid) {
		 String cancellingStatus = bookingService.cancelBooking(bookingid);
		 return cancellingStatus ;
	}
	@PostMapping("/userId/{userId}/turfId/{turfId}/sportsId/{sportsId}/timeslotId/{timeslotId}")
	public String bookTurf(@PathVariable int userId,@PathVariable int turfId,@PathVariable int sportsId,@PathVariable int timeslotId) {
		String status = bookingService.bookTurf(userId,turfId,sportsId,timeslotId);
		return status;
	}
	@GetMapping("/bookingby/timeslotid/{timeslotId}")
	public Bookings getbooking(@PathVariable int timeslotId) {
		return bookingService.getbooking(timeslotId);
		
	}

}
