package com.example.turfSportsBookingSystem.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;


import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Sports {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int sportId;
	
	private String sportName;
	private String pricePerHour;
	
	@ManyToOne
	private Turf turf;
	
	@OneToMany(mappedBy = "sports", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<TimeSlots> slots = new ArrayList<>();

	
	public Sports() {
		
	}


	public int getSportId() {
		return sportId;
	}


	public void setSportId(int sportId) {
		this.sportId = sportId;
	}


	public String getSportName() {
		return sportName;
	}


	public void setSportName(String sportName) {
		this.sportName = sportName;
	}


	public String getPricePerHour() {
		return pricePerHour;
	}


	public void setPricePerHour(String pricePerHour) {
		this.pricePerHour = pricePerHour;
	}


	public Turf getTurf() {
		return turf;
	}


	public void setTurf(Turf turf) {
		this.turf = turf;
	}


	public List<TimeSlots> getSlots() {
		return slots;
	}


	public void setSlots(List<TimeSlots> slots) {
		this.slots = slots;
	}


	public Sports(String sportName, String pricePerHour, Turf turf, List<TimeSlots> slots) {
		super();
		this.sportName = sportName;
		this.pricePerHour = pricePerHour;
		this.turf = turf;
		this.slots = slots;
	}


	@Override
	public String toString() {
		return "Sports [sportId=" + sportId + ", sportName=" + sportName + ", pricePerHour=" + pricePerHour + ", turf="
				+ turf + ", slots=" + slots + "]";
	}


	
}
	











































































//package com.example.turfSportsBookingSystem.entity;
//
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//
//import org.springframework.stereotype.Component;
//
//import com.fasterxml.jackson.annotation.JsonBackReference;
//import com.fasterxml.jackson.annotation.JsonIgnore;
//
//import jakarta.persistence.CascadeType;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.JoinColumn;
//import jakarta.persistence.JoinTable;
//import jakarta.persistence.ManyToMany;
//import jakarta.persistence.ManyToOne;
//import jakarta.persistence.OneToMany;
//
//@Entity
//public class Sports {
//	
//	@Id
//	@GeneratedValue(strategy= GenerationType.IDENTITY)
//	private int sport_id;
//	private String sport_name;
//	private String pricePerHour;
//	
//	@ManyToMany(mappedBy = "sports")
//	@JsonBackReference
//	private Set<Turf> turfs = new HashSet<>();
//	
////	@ManyToMany(cascade = CascadeType.ALL)
//	@ManyToMany
//	@JoinTable(name ="sports_timeslots", 
//	joinColumns = @JoinColumn(name="sports_id"),
//	inverseJoinColumns = @JoinColumn(name="timeslots_id"))
//	private Set<TimeSlots> timeslots = new HashSet<>();
//
//	public Sports() {
//		super();
//	}
//
//	public int getSport_id() {
//		return sport_id;
//	}
//
//	public void setSport_id(int sport_id) {
//		this.sport_id = sport_id;
//	}
//
//	public String getSport_name() {
//		return sport_name;
//	}
//
//	public void setSport_name(String sport_name) {
//		this.sport_name = sport_name;
//	}
//
//	public String getPricePerHour() {
//		return pricePerHour;
//	}
//
//	public void setPricePerHour(String pricePerHour) {
//		this.pricePerHour = pricePerHour;
//	}
//
//	public Set<Turf> getTurfs() {
//		return turfs;
//	}
//
//	public void setTurfs(Set<Turf> turfs) {
//		this.turfs = turfs;
//	}
//
//	public Set<TimeSlots> getTimeslots() {
//		return timeslots;
//	}
//
//	public void setTimeslots(Set<TimeSlots> timeslots) {
//		this.timeslots = timeslots;
//	}
//
//	@Override
//	public String toString() {
//		return "Sports [sport_id=" + sport_id + ", sport_name=" + sport_name + ", pricePerHour=" + pricePerHour
//				+ ", turfs=" + turfs + ", timeslots=" + timeslots + "]";
//	}
//
//	public Sports(int sport_id, String sport_name, String pricePerHour) {
//		super();
//		this.sport_id = sport_id;
//		this.sport_name = sport_name;
//		this.pricePerHour = pricePerHour;
//	}
//
//	 
//
//	
//
//}










































//package com.example.turfSportsBookingSystem.entity;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.stereotype.Component;
//
//
//import com.fasterxml.jackson.annotation.JsonIgnore;
//
//import jakarta.persistence.CascadeType;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.ManyToOne;
//import jakarta.persistence.OneToMany;
//
//@Entity
//public class Sports {
//	
//	@Id
//	@GeneratedValue(strategy= GenerationType.IDENTITY)
//	private int sport_id;
//	
//	private String sport_name;
//	private String pricePerHour;
//	
//	@ManyToOne
//	private Turf turf;
//	
//	@OneToMany(mappedBy = "sports", cascade = CascadeType.ALL)
//	@JsonIgnore
//	private List<TimeSlots> slots = new ArrayList<>();
//
//	
//	public Sports() {
//		
//	}
//
//
//	public int getSport_id() {
//		return sport_id;
//	}
//
//
//	public void setSport_id(int sport_id) {
//		this.sport_id = sport_id;
//	}
//
//
//	public String getSport_name() {
//		return sport_name;
//	}
//
//
//	public void setSport_name(String sport_name) {
//		this.sport_name = sport_name;
//	}
//
//
//	public String getPricePerHour() {
//		return pricePerHour;
//	}
//
//
//	public void setPricePerHour(String pricePerHour) {
//		this.pricePerHour = pricePerHour;
//	}
//
//
//	public Turf getTurf() {
//		return turf;
//	}
//
//
//	public void setTurf(Turf turf) {
//		this.turf = turf;
//	}
//
//
//	public List<TimeSlots> getSlots() {
//		return slots;
//	}
//
//
//	public void setSlots(List<TimeSlots> slots) {
//		this.slots = slots;
//	}
//
//
//	public Sports(int sport_id, String sport_name, String pricePerHour) {
//		super();
//		this.sport_id = sport_id;
//		this.sport_name = sport_name;
//		this.pricePerHour = pricePerHour;
//	}
//
//
//	@Override
//	public String toString() {
//		return "Sports [sport_id=" + sport_id + ", sport_name=" + sport_name + ", pricePerHour=" + pricePerHour
//				+ ", turf=" + turf + ", slots=" + slots + "]";
//	}
//}
	