package com.example.turfSportsBookingSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.turfSportsBookingSystem.entity.Sports;
import com.example.turfSportsBookingSystem.entity.Turf;
import com.example.turfSportsBookingSystem.exception.IdNotFoundException;
import com.example.turfSportsBookingSystem.repository.SportsRepository;
import com.example.turfSportsBookingSystem.repository.TurfRepository;



@Service
public class SportsService {
	@Autowired
	SportsRepository sportsRepository;
	@Autowired
	TurfRepository turfRepository;
	
	public List<Sports> findAll() {
		return sportsRepository.findAll();
	}
	public Optional<Sports> getById(int id){
		if(sportsRepository.findById(id).isEmpty()) {
			throw new IdNotFoundException("Requested Id is not present");
		}
		return sportsRepository.findById(id);
	}
	public List<Sports> getBySportsName(String sportname){
		return sportsRepository.findBySportName(sportname);
	}
	public List<Sports> getBySportsPricePerHour(String pricePerHour){
		return sportsRepository.findByPricePerHour(pricePerHour);
	}

	public Sports addSports(Sports sports) {
		return sportsRepository.save(sports);
	}
	public String updateName(int id,String name) {
		Optional<Sports> sportId = sportsRepository.findById(id);
		if(sportId.isPresent()) {
			Sports sport = sportId.get();
			sport.setSportName(name);
			sportsRepository.save(sport);
			return "Sports Name updated Successfully";
		}else {
			return "Sports is not found by this id";
			}
	}
	public String updatePricePerHour(int id,String PricePerHour) {
		Optional<Sports> sportId = sportsRepository.findById(id);
		if(sportId.isPresent()) {
			Sports sport = sportId.get();
			sport.setPricePerHour(PricePerHour);
			sportsRepository.save(sport);
			return "Sports PricePerHour updated Successfully";
		}else {
			return "Sports is not found by this id";
			}
	}
	public Sports updateSports(Sports sports) {
		return sportsRepository.save(sports);
	}
	public void deleteBySportsId(int id) {
		 sportsRepository.deleteById(id);
	}
	public List<Sports> getByTurfId(int id) {
		Optional<Turf> turfid = turfRepository.findById(id);
		List<Sports> sports =null;
		if(turfid.isPresent()) {
			Turf turf = turfid.get();
			sports = turf.getSports();			
	}
		return  sports;

}
}