package com.example.turfSportsBookingSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.example.turfSportsBookingSystem.entity.TimeSlots;

public interface TimeSlotRepository  extends JpaRepository<TimeSlots,Integer>{

	List<TimeSlots> findByDuration(String duration);

}
